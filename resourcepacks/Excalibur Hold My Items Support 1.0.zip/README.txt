# Hold My Items for Excalibur
══════════════════════════════════════════════════════════════════════════

  	This mod support was created and is maintained by ruseki_
        - You should have the Excalibur Resource Pack for this Add-On Pack to blend properly.
        - Report bugs with the pack to @Ruseki in the Excalibur Discord Channel.
        - I will make updates to the pack as necessary and time allows.


    All credit to Maffhew for Excalibur
        - Download Excalibur (Maffhew)
            - [CurseForge](https://www.curseforge.com/minecraft/texture-packs/excalibur)
            - [Planet Minecraft](https://www.planetminecraft.com/texture-pack/excalibur/)
            - [Modrinth](https://modrinth.com/resourcepack/excal)


Special Thanks To:
══════════════════════════════════════════════════════════════════════════

    Maffhew - For Excalibur and permission to maintain Hold My Items Support
    EnyLow	- For Hold My Items


Excalibur License:
══════════════════════════════════════════════════════════════════════════

    Excalibur by Matt Dillow (Maffhew) is licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
    http://creativecommons.org/licenses/by-nc-nd/3.0/us/

    In other words:
    - You may not redistribute this pack and claim it as your own.
    - You may not redistribute this pack without a link to the official CurseForge or Planet Minecraft Excalibur page.
    - You may not put money-making links such as adf.ly with this work under any circumstances.
    - You may not use this work for commercial purposes.
    - You may not alter, transform, or build upon this work.

    Noncommercial Waiver
    - You may use this Resource Pack as a part of any Minecraft-related video including those which are created for commercial purposes or 
    are monetized by advertising, as long as there's a direct link to an official Excalibur download page.

    Any of the above conditions can be waived if you get permission from Maffhew.
    Discord: @maffhew
    

Hold My Items License:
══════════════════════════════════════════════════════════════════════════
- Author: EnyLow

   - Source: https://www.curseforge.com/minecraft/mc-mods/hold-my-items
   - License: ARR
   - This work is licensed under the All Rights Reserved License.


Under ARR, no permissions are granted to use, copy, modify, or distribute this work unless explicit written authorization is provided by the copyright holder. All rights over the content, its use, and its redistribution remain fully reserved.

----------------------

This project’s original content is released under the following license:
All Rights Reserved.